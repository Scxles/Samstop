// Prevent arrow keys from scrolling
window.addEventListener('keydown', e => {
  if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) e.preventDefault();
});

// Rain effect
const rainCanvas = document.getElementById('rain-canvas'), rctx = rainCanvas.getContext('2d');
let drops = [];
function resizeRain() {
  rainCanvas.width = window.innerWidth;
  rainCanvas.height = window.innerHeight;
  drops = Array.from({ length: 150 }, () => ({
    x: Math.random() * rainCanvas.width,
    y: Math.random() * rainCanvas.height,
    l: Math.random() * 20 + 10
  }));
}
window.addEventListener('resize', resizeRain);
resizeRain();
(function draw() {
  rctx.clearRect(0,0,rainCanvas.width,rainCanvas.height);
  rctx.strokeStyle='rgba(155,89,182,0.6)';
  drops.forEach(d => {
    rctx.beginPath();
    rctx.moveTo(d.x,d.y);
    rctx.lineTo(d.x,d.y+d.l);
    rctx.stroke();
    d.y+=4; if(d.y>rainCanvas.height) d.y=-d.l;
  });
  requestAnimationFrame(draw);
})();

// Features: static currencies & crypto with update date
const fTabs=document.querySelectorAll('#features-tabs button'), fCont=document.getElementById('features-container');
fTabs.forEach(btn=>btn.addEventListener('click',()=>{ fTabs.forEach(b=>b.classList.remove('active')); btn.classList.add('active'); loadFeatures(btn.dataset.tab); }));

function loadFeatures(tab) {
  const fCont = document.getElementById('features-container');
  fCont.innerHTML = '';
  if (tab === 'currencies') {
    const info = document.createElement('div');
    info.className = 'info-box';
    info.textContent = 'Last updated: 2025-04-21';
    fCont.appendChild(info);

    const currencies = [
      {country:'European Union', code:'EUR', rate:1.0900},
      {country:'Japan', code:'JPY', rate:0.0068},
      {country:'United Kingdom', code:'GBP', rate:1.2500},
      {country:'Australia', code:'AUD', rate:0.6700},
      {country:'Canada', code:'CAD', rate:0.7500},
      {country:'Switzerland', code:'CHF', rate:1.0800},
      {country:'China', code:'CNY', rate:0.1400},
      {country:'Sweden', code:'SEK', rate:0.0940},
      {country:'New Zealand', code:'NZD', rate:0.6000},
      {country:'United States', code:'USD', rate:1.0000}
    ];
    currencies.forEach(c => {
      const card = document.createElement('div');
      card.className = 'weather-card';
      card.textContent = `${c.country} (${c.code}) = $${c.rate.toFixed(4)} USD`;
      fCont.appendChild(card);
    });
  } else if (tab === 'crypto') {
    const info = document.createElement('div');
    info.className = 'info-box';
    info.textContent = 'Last updated: 2025-04-21';
    fCont.appendChild(info);

    const list = document.createElement('div');
    list.className = 'weather-list';
    fCont.appendChild(list);

    const ids = ['bitcoin','ethereum','binancecoin','tether','ripple'];
    const names = ['BTC','ETH','BNB','USDT','XRP'];
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=' + ids.join('%2C') + '&vs_currencies=usd')
      .then(r => r.json())
      .then(data => {
        ids.forEach((id, i) => {
          const cName = names[i];
          const price = data[id].usd;
          const card = document.createElement('div');
          card.className = 'weather-card';
          card.textContent = `${cName} = $${price}`;
          list.appendChild(card);
        });
      });
  } else if (tab === 'coming') {
    fCont.textContent = 'Coming Soon...';
  }
}

loadFeatures('currencies');

// Games
const gTabs=document.querySelectorAll('#game-tabs button'), gCont=document.getElementById('game-container');
gTabs.forEach(btn=>btn.addEventListener('click',()=>{ gTabs.forEach(b=>b.classList.remove('active')); btn.classList.add('active'); loadGame(btn.dataset.game); }));
function loadGame(name){
  gCont.innerHTML='';
  if(name==='blackjack') loadBlackjack();
  if(name==='snake') loadSnake();
  if(name==='coming') gCont.textContent='Coming Soon...';
}
// Auto-load Blackjack
loadGame('blackjack');

// Blackjack
function loadBlackjack(){
  const gCont = document.getElementById('game-container');
  gCont.innerHTML = '';
  const iframe = document.createElement('iframe');
  iframe.src = 'blackjack-master/index.html';
  iframe.style.width = '100%';
  iframe.style.height = '600px';
  iframe.style.border = 'none';
  gCont.appendChild(iframe);
}

// Snake with score
function loadSnake(){
  const div=document.createElement('div'); div.id='snake';
  const sd=document.createElement('div'); sd.id='snake-score'; sd.textContent='Score: 0'; div.appendChild(sd);
  const canvas=document.createElement('canvas'); canvas.id='snake-canvas'; canvas.width=400; canvas.height=400; div.appendChild(canvas); gCont.appendChild(div);
  const ctx=canvas.getContext('2d'); let snake=[{x:200,y:200}], dir={x:20,y:0}, food={}, scoreVal=0;
  function placeFood(){ food={x:Math.floor(Math.random()*20)*20, y:Math.floor(Math.random()*20)*20}; }
  document.addEventListener('keydown', e=>{ if(e.key==='ArrowUp') dir={x:0,y:-20}; if(e.key==='ArrowDown') dir={x:0,y:20}; if(e.key==='ArrowLeft') dir={x:-20,y:0}; if(e.key==='ArrowRight') dir={x:20,y:0}; });
  function loop(){ const head={x:snake[0].x+dir.x, y:snake[0].y+dir.y}; snake.unshift(head); if(head.x===food.x&&head.y===food.y){ scoreVal+=10; sd.textContent=`Score: ${scoreVal}`; placeFood(); } else snake.pop(); if(head.x<0||head.x>=400||head.y<0||head.y>=400) reset(); ctx.fillStyle='#111'; ctx.fillRect(0,0,400,400); ctx.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--accent'); snake.forEach(s=>ctx.fillRect(s.x,s.y,20,20)); ctx.fillStyle='#fff'; ctx.fillRect(food.x,food.y,20,20); }
  function reset(){ snake=[{x:200,y:200}]; dir={x:20,y:0}; scoreVal=0; sd.textContent='Score: 0'; placeFood(); }
  placeFood(); setInterval(loop,100);
}

// Weather unchanged
const cities=[{name:'Jacksonville, AL',lat:34.8071,lon:-85.7794},{name:'Alexander City, AL',lat:32.9360,lon:-85.9456},{name:'Auburn, AL',lat:32.6099,lon:-85.4808}];
const ww=document.getElementById('weather-widgets');
cities.forEach(c=>{ const card=document.createElement('div'); card.className='weather-card'; card.innerHTML=`<h3>${c.name}</h3><p>Loading...</p>`; ww.appendChild(card);
  fetch(`https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current_weather=true`)
    .then(r=>r.json()).then(data=>{ const w=data.current_weather; const f=(w.temperature*9/5+32).toFixed(1); card.innerHTML=`<h3>${c.name}</h3><p>Temp: ${f}°F</p>`; })
    .catch(()=>{ card.innerHTML=`<h3>${c.name}</h3><p>Error</p>`; });
});

// Contact
document.getElementById('contact-form').onsubmit = e => { e.preventDefault(); alert('Thanks for your message!'); };
